import io
import pandas as pd
import numpy as np

from mlxtend.frequent_patterns import apriori, association_rules
from scipy.sparse import csr_matrix

from django.conf import settings
from sistema.models import UsuarioDiasGenerico

import os
import io
import pandas as pd
import numpy as np
import tensorflow as tf
import random

from mlxtend.frequent_patterns import apriori, association_rules
from scipy.sparse import csr_matrix

from django.conf import settings
from sistema.models import UsuarioDiasGenerico

# Camino al modelo dentro del proyecto Django
model_path = os.path.join(settings.BASE_DIR, 'modelos/UsuarioRecomendacionModelo')
# Cargar el modelo
recommender_model = tf.saved_model.load(model_path)
infer = recommender_model.signatures['serving_default']


def get_recommendationsTensor(user_id):

    item_id_mapping = obtener_mapeo()

    item_ids_generico = np.array(sorted(item_id_mapping.keys()))
    item_ids = np.array([item_id_mapping[gen_id] for gen_id in item_ids_generico])

    # Preparar los inputs en el formato adecuado
    predictions = infer(user_id=tf.constant([user_id] * len(item_ids)), item_id=tf.constant(item_ids))
    predictions = predictions['output_1'].numpy().flatten()  # Asegúrate de que 'output' es el nombre correcto de la salida
    
    top_5_items_indices = np.argsort(-predictions)[:5]
    top_5_items_scores = predictions[top_5_items_indices]
    top_5_items_ids = item_ids_generico[top_5_items_indices]

    recommended_items = [{"item_id": int(item_id), "score": float(score)} for item_id, score in zip(top_5_items_ids, top_5_items_scores)]
    return recommended_items

def get_recommendations_for_new_user(user_count=2):
    # Supongamos que tienes una función que puede listar todos los usuarios
    all_users = list(range(1, 951))   # Esta función debe retornar una lista de todos los usuarios
    selected_users = random.sample(all_users, user_count)
    
    # Diccionario para sumar puntuaciones
    product_scores = {}

    for user_id in selected_users:
        recommendations = get_recommendationsTensor(user_id)  # Suponemos que esta función ya existe
        for item in recommendations:
            if item['item_id'] in product_scores:
                product_scores[item['item_id']] += item['score']
            else:
                product_scores[item['item_id']] = item['score']
    
    # Tomar el promedio y seleccionar los 5 productos más altos
    # Dividir cada puntuación por user_count para obtener el promedio
    for product in product_scores:
        product_scores[product] /= user_count
    
    # Ordenar productos por puntuación y seleccionar los 5 mejores
    top_5_items = sorted(product_scores.items(), key=lambda x: x[1], reverse=True)[:5]
    return [{"item_id": item[0], "score": item[1]} for item in top_5_items]


def obtener_matriz_usuario_producto():
    # Leer datos usando Django ORM
    datos = UsuarioDiasGenerico.objects.all().values('usuario', 'generico_id', 'dias_consumidos')

    # Convertir a DataFrame
    data = pd.DataFrame(list(datos))

    # Convertir ID_Usuario y ID_Generico a categorías
    data['usuario'] = data['usuario'].astype('category')
    data['generico_id'] = data['generico_id'].astype('category')

    # Crear un mapeo de los antiguos IDs a los nuevos índices continuos
    item_id_mapping = {old_id: i for i, old_id in enumerate(sorted(data['generico_id'].cat.categories))}
    data['generico_id'] = data['generico_id'].map(item_id_mapping)

    #print(item_id_mapping)

    # Crear matriz de usuario-producto con los nuevos índices
    basket = (data
          .groupby(['usuario', 'generico_id'], observed=True)['dias_consumidos']
          .sum().unstack(fill_value=0))

    #print(basket)

    # Convertir a matriz dispersa
    sparse_basket = csr_matrix(basket > 0)

    # Convertir la matriz dispersa de nuevo a DataFrame de Pandas
    dense_basket = pd.DataFrame(sparse_basket.toarray(), columns=basket.columns, index=basket.index)
    #print(dense_basket)

    #print(sparse_basket)

    return dense_basket

def obtener_mapeo():
    # Leer datos usando Django ORM
    datos = UsuarioDiasGenerico.objects.all().values('usuario', 'generico_id', 'dias_consumidos')

    # Convertir a DataFrame
    data = pd.DataFrame(list(datos))

    # Convertir ID_Usuario y ID_Generico a categorías
    data['usuario'] = data['usuario'].astype('category')
    data['generico_id'] = data['generico_id'].astype('category')

    # Crear un mapeo de los antiguos IDs a los nuevos índices continuos
    item_id_mapping = {old_id: i for i, old_id in enumerate(sorted(data['generico_id'].cat.categories))}
    
    return item_id_mapping

def generar_recomendaciones(dense_basket):
    # Ajuste para asegurarse que todos los datos son booleanos
    dense_basket = dense_basket.apply(lambda x: x > 0, axis=1)
    # Ensure all values are boolean
    dense_basket = dense_basket.astype(bool)

    # Generar conjuntos frecuentes usando el algoritmo Apriori
    frequent_itemsets = apriori(dense_basket, min_support=0.3, use_colnames=True)
    #print("Frequent Itemsets:")
    #print(frequent_itemsets)

    # Generar reglas de asociación
    rules = association_rules(frequent_itemsets, metric="lift", min_threshold=1)
    #print("Association Rules:")
    #print(rules)

    return rules

def recomendar_productos_complejos(carrito, reglas):
    # Obtener el mapeo de ID a índice
    mapeo_id = obtener_mapeo()
    mapeo_inverso = {v: k for k, v in mapeo_id.items()}
    
    # Mapear los IDs del carrito a los índices
    carrito_indices = [mapeo_id[item] for item in carrito if item in mapeo_id]
    carrito_set = set(carrito_indices)
    recomendaciones_finales = {}

    # Buscar reglas donde el conjunto completo de antecedentes sea igual al carrito
    recomendaciones_conjunto = reglas[reglas['antecedents'].apply(lambda x: x == carrito_set)]
    productos_recomendados_conjunto = set()
    for index, row in recomendaciones_conjunto.iterrows():
        productos_recomendados_conjunto.update(row['consequents'])
    productos_recomendados_conjunto.difference_update(carrito_set)

    # Convertir índices a IDs originales y agrupar las recomendaciones
    if productos_recomendados_conjunto:
        recomendaciones_finales['Carrito_completo'] = [
            mapeo_inverso[producto] for producto in productos_recomendados_conjunto if producto in mapeo_inverso
        ]

    # Procesar cada ítem en el carrito individualmente
    if len(productos_recomendados_conjunto) < 3:
        for item in carrito_indices:
            recomendaciones_item = reglas[reglas['antecedents'].apply(lambda x: set(x) == {item})]
            productos_recomendados_item = set()
            for index, row in recomendaciones_item.iterrows():
                productos_recomendados_item.update(row['consequents'])
            productos_recomendados_item.difference_update(carrito_set)
            recomendaciones_finales[mapeo_inverso[item]] = [
                mapeo_inverso[producto] for producto in productos_recomendados_item if producto in mapeo_inverso
            ]

    return recomendaciones_finales
