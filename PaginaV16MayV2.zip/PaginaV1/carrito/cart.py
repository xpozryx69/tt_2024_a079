from sistema.models import Especificacion

class Cart():
    def __init__(self, request):
        self.session = request.session

        cart = self.session.get('session_key')

        if 'session_key' not in request.session:
            cart = self.session['session_key'] = {}

        self.cart = cart

    def add(self, product):
        product_id = str(product.id_especificacion)

        if product_id in self.cart:
            pass
        else:
            self.cart[product_id] = {'nombre': str(product.especificacion)}

        self.session.modified = True

    def __len__(self):
        return len(self.cart)

    def get_products(self):
        #Obtener IDs del carro
        product_ids = self.cart.keys()
        products = Especificacion.objects.filter(id_especificacion__in=product_ids)
        return products

    def get_products_ids(self):
        #Obtener IDs del carro
        product_ids = self.cart.keys()
        return product_ids

    def delete(self, product):
        product_id = str(product)
        if product_id in self.cart:
            del self.cart[product_id]

        self.session.modified = True