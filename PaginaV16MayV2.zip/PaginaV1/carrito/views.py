from django.shortcuts import render, get_object_or_404
from .cart import Cart
from sistema.models import Especificacion, GenericoMarcaEspecificacionRelacion, Generico
from django.http import JsonResponse

from .utils import obtener_matriz_usuario_producto, generar_recomendaciones,recomendar_productos_complejos, obtener_mapeo, get_recommendationsTensor, get_recommendations_for_new_user

# Create your views here.

def carrito_resumen(request):
    cart = Cart(request)
    productos_carrito = cart.get_products
    ids_carrito = list(cart.get_products_ids())

    # Buscar los genéricos relacionados a través del modelo de relación
    relaciones = GenericoMarcaEspecificacionRelacion.objects.filter(
        id_especificacion__id_especificacion__in=ids_carrito
    ).select_related('id_generico')
    
    # Extraer los genéricos directamente
    prod_genericos = [relacion.id_generico for relacion in relaciones]
    ids_genericos = [generico.id_generico for generico in prod_genericos]

    # Recuperar todos los productos recomendados y los productos genéricos en el carrito
    todos_ids = set(ids_genericos)  # Suponiendo que ids_genericos ya contiene los ids del carrito

    ########## Recomendacion ##########
    matriz_usuario_producto = obtener_matriz_usuario_producto()
    reglas = generar_recomendaciones(matriz_usuario_producto)
    
    carrito = ids_genericos
    productos_recomendados = recomendar_productos_complejos(carrito, reglas)

    # Incluir todas las recomendaciones para asegurarse de tener sus objetos
    for lista_ids in productos_recomendados.values():
        todos_ids.update(lista_ids)
    
    # Obtener objetos de todos los IDs de productos genéricos necesarios
    productos_genericos = Generico.objects.in_bulk(list(todos_ids))

    recomendaciones_contexto = {
        productos_genericos[id].nombre_generico: [productos_genericos[rec_id].nombre_generico for rec_id in recomendaciones]
        for id, recomendaciones in productos_recomendados.items() if id != 'Carrito_completo'
    }

    if 'Carrito_completo' in productos_recomendados:
        recomendaciones_contexto['Carrito_completo'] = [productos_genericos[rec_id].nombre_generico for rec_id in productos_recomendados['Carrito_completo']]

    context = {
        "productos_carrito":productos_carrito,
        "ids_carrito":ids_carrito,
        "productos_genericos":productos_genericos,
        "ids_genericos":ids_genericos,
        #"productos_carrito": [productos_genericos[id] for id in ids_genericos],
        "productos_recomendados": recomendaciones_contexto,
        #productos_recomendados": {id: [productos_genericos[rec_id] for rec_id in recomendaciones] 
                                   #for id, recomendaciones in productos_recomendados.items()},
        "relaciones":relaciones,
    }
    
    return render(request, "pages/carrito_resumen.html", context)

def carrito_add(request):
    cart = Cart(request)
    if request.POST.get('action') == 'post':
        producto_id = int(request.POST.get('product_id'))
        producto = get_object_or_404(Especificacion, id_especificacion=producto_id)
        cart.add(product=producto)

        cart_quantity = cart.__len__()
        #response = JsonResponse({'Product Name': producto.especificacion})
        response = JsonResponse({'Cantidad': cart_quantity})
        return response

def carrito_delete(request):
    cart = Cart(request)
    if request.POST.get('action') == 'post':
        product_id = int(request.POST.get('product_id'))

        cart.delete(product=product_id)

        response = JsonResponse({'product': product_id})
        return response
        

def carrito_update(request):
    pass

def pruebas2(request):
    
    context = {}
    # Verificar si las coordenadas están en la sesión
    coords = request.session.get('coords', None)
    if coords:
        context['coords'] = coords
    else:
        context['coords'] = {'lat': 'No definida', 'lng': 'No definida'}

    return render(request, "pages/pruebas2.html", context)
