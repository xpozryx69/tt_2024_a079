class LocationHandler():
    def __init__(self, request):
        self.session = request.session
        # Inicializar las coordenadas si aún no están en la sesión
        if 'coords' not in self.session:
            self.session['coords'] = {'lat': None, 'lng': None}

    def set_coordinates(self, lat, lng):
        # Actualizar las coordenadas en la sesión
        self.session['coords'] = {'lat': lat, 'lng': lng}
        self.session.modified = True

    def get_coordinates(self):
        # Retornar las coordenadas
        return self.session.get('coords', {'lat': 'No definida', 'lng': 'No definida'})