from .models import Clase, Generico, Especificacion, GenericoMarcaEspecificacionRelacion
from .obtencion_localizacion import LocationHandler
from carrito.cart import Cart

def navbarAll(request):
    clases = Clase.objects.all()  # Obtener todas las clases
    genericos = Generico.objects.all()  # Obtener todos los genéricos
    especificaciones = Especificacion.objects.all()  # Obtener todas las especificaciones

    location_handler = LocationHandler(request)
    coords = location_handler.get_coordinates() 

    cart = Cart(request)
    productos_carrito = cart.get_products
    ids_carrito = list(cart.get_products_ids())

    # Buscar los genéricos relacionados a través del modelo de relación
    relaciones = GenericoMarcaEspecificacionRelacion.objects.filter(
        id_especificacion__id_especificacion__in=ids_carrito
    ).select_related('id_generico')

    # Pasando múltiples contextos a la plantilla
    context = {
        'clasesnav': clases,
        'genericosnav': genericos,
        'especificacionesnav': especificaciones,
        'latitude': coords['lat'] if coords['lat'] is not None else 'No definida',
        'longitude': coords['lng'] if coords['lng'] is not None else 'No definida',
        'relacionesnav': relaciones,
    }

    return (context)