# utils.py
from geopy.distance import geodesic

def calcular_distancia_maxima(coords, detalles):
    max_distance = 0  # Inicializa la máxima distancia
    for detalle in detalles:
        if detalle.coordenada_x is not None and detalle.coordenada_y is not None:
            distancia = geodesic(
                (coords['lat'], coords['lng']),
                (detalle.coordenada_x, detalle.coordenada_y)
            ).kilometers
            distancia = round(distancia, 2)  # Redondea la distancia a dos decimales
            if distancia > max_distance:
                max_distance = distancia
    return max_distance

def calcular_distancia(origen, destino):
    distancia = geodesic((origen['lat'], origen['lng']), (destino['lat'], destino['lng'])).km
    distancia = round(distancia, 2)
    return distancia

def calcular_distancia_minima(coords, detalles):
    min_distance = float('inf')  # Inicializa la distancia mínima como infinito
    for detalle in detalles:
        if detalle.coordenada_x is not None and detalle.coordenada_y is not None:
            distancia = geodesic(
                (coords['lat'], coords['lng']),
                (detalle.coordenada_x, detalle.coordenada_y)
            ).kilometers
            distancia = round(distancia, 2)  # Redondea la distancia a dos decimales
            if distancia < min_distance:
                min_distance = distancia
    if min_distance == float('inf'):
        min_distance = 0  # Si no se encuentra ninguna distancia válida, establece la distancia mínima como 0
    return min_distance