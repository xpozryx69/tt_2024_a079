from django.urls import path
from . import views 
from .views import add_review

urlpatterns = [
    path('', views.index, name='index'),
    path('pruebas/', views.pruebas, name='pruebas'),
    path('pages/about/', views.about, name='about'),
    path('pages/login/', views.login_user, name='login'),
    path('pages/logout/', views.logout_user, name='logout'),
    path('pages/producto/<int:pk>', views.producto, name='producto'),
    path('pages/categoria-generico/<str:generico>', views.categoria_g, name='categoria_g'),
    path('pages/categoria-clase/<str:clase>', views.categoria_c, name='categoria_c'),
    path('pages/categoria-tiendas/', views.categoria_tiendas, name='categoria_tiendas'),
    path('add_coords/', views.add_coords, name='add_coords'),
    path('proveedor-tiendas/<int:pk>/<str:proveedor>', views.proveedor_tiendas, name='proveedor_tiendas'),
    path('pages/contacto', views.contacto, name='contacto'),
    path('producto/<int:pk>/add_review/', add_review, name='add_review'),
    path('pages/categoria-generico-all/', views.todos_los_genericos, name='todos_los_genericos'),
]
