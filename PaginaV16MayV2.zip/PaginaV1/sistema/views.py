from django.shortcuts import render, redirect, get_object_or_404
from django.core.exceptions import MultipleObjectsReturned, ObjectDoesNotExist
from django.db.models import Sum, Prefetch, Avg
from django.urls import reverse

from .models import (
    Clase, Generico, Especificacion, Precio, UsuarioDiasGenerico,
    GenericoMarcaEspecificacionRelacion, ClaseGenericoRelacion,
    PrecioPromedio, Estado, Municipio, DetalleProveedor, 
    Proveedor, CategoriaProveedor, CategoriaProveedorGenerico,
    Contacto, Review
)

from .utils import calcular_distancia_maxima, calcular_distancia, calcular_distancia_minima

from django.contrib.auth import authenticate, login, logout
from django.contrib import messages
from django.http import JsonResponse, HttpResponseRedirect
from django.core.paginator import Paginator, PageNotAnInteger, EmptyPage
from django.utils import timezone

from .obtencion_localizacion import LocationHandler

from carrito.utils import get_recommendationsTensor, get_recommendations_for_new_user

# Create your views here.

def index(request):
    clases = Clase.objects.all()  # Obtener todas las clases
    genericos = Generico.objects.all()  # Obtener todos los genéricos
    especificaciones = Especificacion.objects.all()  # Obtener todas las especificaciones

    productos_consumo = UsuarioDiasGenerico.objects.values('generico', 'generico__nombre_generico', 'generico__imagen').annotate(total_dias_consumidos=Sum('dias_consumidos')).order_by('-total_dias_consumidos')

    recommended_items = get_recommendations_for_new_user()
    # Crear una lista de los IDs de los ítems recomendados
    item_ids = [item['item_id'] for item in recommended_items]

    # Obtener los nombres de los ítems usando los IDs en una sola consulta
    items = Generico.objects.filter(id_generico__in=item_ids).only('id_generico', 'nombre_generico', 'imagen')

    # Crear un diccionario para acceder rápidamente por id_generico
    item_dict = {item.id_generico: {'nombre': item.nombre_generico, 'imagen_url': item.imagen.url if item.imagen else None} for item in items}

    # Añadir el nombre y URL de la imagen de cada ítem a la lista de recomendados
    for item in recommended_items:
        item_info = item_dict.get(item['item_id'], {'nombre': 'Item desconocido', 'imagen_url': None})
        item['nombre_generico'] = item_info['nombre']
        item['imagen_url'] = item_info['imagen_url']

    # Pasando múltiples contextos a la plantilla
    context = {
        'clases': clases,
        'genericos': genericos,
        'especificaciones': especificaciones,
        'productos_consumo': productos_consumo[:7],
        'recommended_items':recommended_items,
    }

    return render(request, 'index.html', context)

#########################################################################################################

def add_review(request, pk):
    producto = get_object_or_404(Especificacion, id_especificacion=pk)
    if request.method == 'POST':
        titulo = request.POST.get('titulo')
        comentario = request.POST.get('comentario')
        calificacion = int(request.POST.get('calificacion'))
        session_key = request.session.session_key or request.session.create()

        Review.objects.create(
            producto_especifico=producto,
            titulo=titulo,
            comentario=comentario,
            calificacion=calificacion,
            fecha_creacion=timezone.now(),
            session_key=session_key
        )
        # Redirige al usuario de vuelta a la página de detalles del producto
        messages.success(request, ("Resena agregada con exito"))
        return HttpResponseRedirect(reverse('producto', args=[pk]))
    # Si no es POST, simplemente redirige al usuario de vuelta a la página del producto
    return HttpResponseRedirect(reverse('producto', args=[pk]))

def producto(request, pk):
    # Primero obtenemos la especificación usando get_object_or_404 para manejar casos donde el PK no existe
    producto = get_object_or_404(Especificacion, id_especificacion=pk)

    reviews = producto.reviews.all().order_by('-fecha_creacion')  # Obtener todas las reseñas del producto ordenadas por fecha
    stars_range = range(1, 6)

    # Intentamos obtener la relación y, consecuentemente, la marca y el genérico asociados
    try:
        """relacion = GenericoMarcaEspecificacionRelacion.objects.select_related('id_generico', 'id_marca').get(id_especificacion=producto)
        clase_generico = ClaseGenericoRelacion.objects.select_related('id_clase').get(id_generico=relacion.id_generico)
        clase = clase_generico.id_clase"""
        # Usamos filter y first para manejar múltiples objetos
        relacion = GenericoMarcaEspecificacionRelacion.objects.select_related('id_generico', 'id_marca').filter(id_especificacion=producto).first()
        if relacion:
            # Filtrar precios no solo por especificación, sino también asegurando que sea del genérico correcto
            precios = PrecioPromedio.objects.filter(
                especificacion=producto,
                generico=relacion.id_generico
            ).order_by('-ano', '-mes')[:12]  # Los últimos 12 precios por año y mes

            ultimo_precio = precios.first() if precios.exists() else None

            clase_generico = ClaseGenericoRelacion.objects.select_related('id_clase').filter(id_generico=relacion.id_generico).first()
            clase = clase_generico.id_clase if clase_generico else None
    
            # Recomendaciones basadas en la misma marca
            recomendaciones_marca = GenericoMarcaEspecificacionRelacion.objects.filter(id_marca=relacion.id_marca).exclude(id_especificacion=pk).select_related('id_especificacion', 'id_generico').distinct()
            recomendaciones_marca_datos = []
            for rel in recomendaciones_marca:
                id_especificacion = rel.id_especificacion
                nombre_generico = rel.id_generico.nombre_generico  # Obteniendo el nombre del genérico
                ultimo_precio_rec = PrecioPromedio.objects.filter(especificacion=id_especificacion).order_by('-ano', '-mes').first()
                calificacion_promedio = Review.objects.filter(producto_especifico=id_especificacion).aggregate(Avg('calificacion'))['calificacion__avg']
                calificacion_promedio = round(calificacion_promedio, 1) if calificacion_promedio is not None else None

                recomendaciones_marca_datos.append({
                    'producto': id_especificacion,
                    'generico': nombre_generico,  # Añadir el nombre del genérico
                    'ultimo_precio': ultimo_precio_rec,
                    'calificacion_promedio': calificacion_promedio
                })

            recomendaciones_generico = GenericoMarcaEspecificacionRelacion.objects.filter(id_generico=relacion.id_generico).exclude(id_especificacion=pk).select_related('id_especificacion', 'id_generico').distinct()
            recomendaciones_generico_datos = []
            for rel in recomendaciones_generico:
                id_especificacion = rel.id_especificacion
                nombre_generico = rel.id_generico.nombre_generico  # Obteniendo el nombre del genérico
                ultimo_precio_rec = PrecioPromedio.objects.filter(especificacion=id_especificacion).order_by('-ano', '-mes').first()
                calificacion_promedio = Review.objects.filter(producto_especifico=id_especificacion).aggregate(Avg('calificacion'))['calificacion__avg']
                calificacion_promedio = round(calificacion_promedio, 1) if calificacion_promedio is not None else None

                recomendaciones_generico_datos.append({
                    'producto': id_especificacion,
                    'generico': nombre_generico,  # Añadir el nombre del genérico
                    'ultimo_precio': ultimo_precio_rec,
                    'calificacion_promedio': calificacion_promedio
                })


            # Recomendaciones basadas en la misma clase
            productos_similares_clase = ClaseGenericoRelacion.objects.filter(
                id_clase=clase
            ).exclude(id_generico=relacion.id_generico).select_related('id_generico').distinct()

            # Extraer los genéricos relacionados con la misma clase
            recomendaciones_clase = [rel.id_generico for rel in productos_similares_clase]

    except GenericoMarcaEspecificacionRelacion.DoesNotExist:
        relacion = None
        genericos_clases = None
        recomendaciones_generico = []
        recomendaciones_clase = []
    
    except MultipleObjectsReturned:
        # Puedes registrar este error si es inesperado o manejar de alguna manera específica
        print("Advertencia: Se esperaba un solo objeto, pero se encontraron múltiples.")
        relacion = None
        clase = None

    if relacion:
        # Suponiendo que ya tienes el generico, obtenemos las categorías de proveedores para ese genérico
        categorias_proveedor = CategoriaProveedorGenerico.objects.filter(
            id_generico=relacion.id_generico
        ).select_related('categoria_proveedor')

        location_handler = LocationHandler(request)
        coords = location_handler.get_coordinates()  # Coordenadas de la sesión

        # Ahora obtenemos los proveedores para esas categorías
        recomendaciones_proveedores = []
        for categoria in categorias_proveedor:
            proveedores = Proveedor.objects.filter(
                categoria_proveedor=categoria.categoria_proveedor
            )
            for proveedor in proveedores:
                detalles = DetalleProveedor.objects.filter(proveedor=proveedor)
                min_distance = calcular_distancia_minima(coords, detalles)
                proveedor.min_distance = min_distance
            recomendaciones_proveedores.extend(proveedores)
    else:
        recomendaciones_proveedores = []
    
    recomendaciones_proveedores = sorted(recomendaciones_proveedores, key=lambda x: x.min_distance)


    # Pasamos la especificación, el genérico y la marca (si existen) al contexto
    context = {
        'producto': producto,
        'generico': relacion.id_generico if relacion else None,
        'marca': relacion.id_marca if relacion else None,
        'clase': clase,
        'recomendaciones_marca': recomendaciones_marca_datos[:10],  # Lista de productos recomendados
        'recomendaciones_generico': recomendaciones_generico_datos[:5],
        'recomendaciones_clase': recomendaciones_clase[:5],
        'precios': precios,
        'ultimo_precio': ultimo_precio,
        "recomendaciones_proveedores":recomendaciones_proveedores,
        "reviews":reviews,
        "stars_range":stars_range,
    }

    return render(request, 'pages/producto.html', context)

#########################################################################################################

def categoria_g(request, generico):
    #Remplaza los espacios
    generico = generico.replace('-', ' ')
    
    # Obtiene el objeto Generico basado en el nombre
    categoria = get_object_or_404(Generico, nombre_generico=generico)
    
    # Obtiene todas las relaciones donde aparece este generico
    relaciones = GenericoMarcaEspecificacionRelacion.objects.filter(id_generico=categoria)
    
    # Prepara una lista para guardar los objetos Especificacion
    productos = [rel.id_especificacion for rel in relaciones]

     # Crear una lista con productos y sus datos asociados (último precio, reseñas)
    productos_con_datos = []

    for producto in productos:
        # Obtener el último precio
        ultimo_precio = PrecioPromedio.objects.filter(especificacion_id=producto).order_by('-ano', '-mes').first()

        # Obtener todas las reseñas del producto
        reviews = Review.objects.filter(producto_especifico=producto).order_by('-fecha_creacion')
        
        # Calcular la calificación promedio del producto si tiene reseñas
        if reviews.exists():
            calificacion_promedio = round(reviews.aggregate(Avg('calificacion'))['calificacion__avg'], 1)
        else:
            calificacion_promedio = None
        
        # Añadir el producto con sus datos al listado
        productos_con_datos.append({
            'producto': producto,
            'ultimo_precio': ultimo_precio,
            'calificacion_promedio': calificacion_promedio,
            'reviews_count': reviews.count()
        })
    
    # Lista de estrellas para mostrar un rango de 1 a 5
    stars_range = list(range(1, 6))

    # Prepara el contexto para la plantilla
    context = {
        'productos': productos,
        'productos_con_datos': productos_con_datos,
        'categoria': categoria,
        "stars_range":stars_range,
    }

    return render(request, 'pages/categoria-generico.html', context)

def categoria_c(request, clase):
    # Reemplaza los guiones con espacios
    nom_clase = clase.replace('-', ' ')
    
    # Obtiene el objeto Clase basado en el nombre
    categoria = get_object_or_404(Clase, clase=nom_clase)
    
    # Obtiene todas las relaciones donde aparece esta clase y extrae los Genericos asociados
    genericos = Generico.objects.filter(clasegenericorelacion__id_clase=categoria)
    
    # Prepara el contexto para la plantilla
    context = {
        'genericos': genericos,
        'categoria': categoria,
    }

    return render(request, 'pages/categoria-clase.html', context)

def todos_los_genericos(request):
    # Obtener todos los productos genéricos
    genericos = Generico.objects.all()

    # Crear el paginador para dividir el conjunto en páginas de 40
    paginator = Paginator(genericos, 40)
    page = request.GET.get('page')  # Obtener el número de página desde la URL

    try:
        genericos_paginados = paginator.page(page)
    except PageNotAnInteger:
        # Si el valor de `page` no es un entero, mostrar la primera página
        genericos_paginados = paginator.page(1)
    except EmptyPage:
        # Si `page` está fuera de rango (demasiado alto), mostrar la última página
        genericos_paginados = paginator.page(paginator.num_pages)

    # Pasar los genericos paginados al contexto
    context = {
        'genericos': genericos_paginados
    }

    return render(request, 'pages/categoria-genericos-all.html', context)


#########################################################################################################

def contacto(request):
    
    if request.method == 'POST':
        email = request.POST.get('contactEmail')
        confirm_email = request.POST.get('confirmEmail')

        if email != confirm_email:
            messages.error(request, 'Los emails no coinciden.')
            return redirect('nombre_de_tu_url_de_contacto')

        nuevo_contacto = Contacto(
            nombre=request.POST.get('contactFName'),
            apellido=request.POST.get('contactLName'),
            titulo=request.POST.get('contactTitle'),
            email=email,
            comentario=request.POST.get('contactTearea')
        )
        nuevo_contacto.save()
        messages.success(request, ("Tu información ha sido enviada correctamente"))
        return redirect('contacto')
    else:
        return render(request, 'pages/contacto.html')

#########################################################################################################

def categoria_tiendas(request):
    
    location_handler = LocationHandler(request)
    coords = location_handler.get_coordinates()  # Coordenadas de la sesión
    
    # Obtiene el filtro de categoría desde la petición, si existe
    categoria_filtro = request.GET.get('categoria', '')

    # Filtra los proveedores basándose en la categoría si se especificó una
    if categoria_filtro:
        proveedores = Proveedor.objects.filter(categoria_proveedor__descripcion=categoria_filtro)
    else:
        proveedores = Proveedor.objects.all()

    proveedores = proveedores.select_related(
        'categoria_proveedor'
    ).prefetch_related(
        Prefetch('detalleproveedor_set', queryset=DetalleProveedor.objects.select_related(
            'municipio__estados'
        ))
    )

    # Calcular la distancia máxima para cada proveedor y guardarla como atributo
    for proveedor in proveedores:
        detalles = list(proveedor.detalleproveedor_set.all())
        proveedor.min_distance = calcular_distancia_minima(coords, detalles)

    # Ordenar los proveedores por la distancia mínima calculada
    proveedores = sorted(proveedores, key=lambda x: x.min_distance)

    # Obtener todas las categorías para el filtro del formulario
    categorias = CategoriaProveedor.objects.all()

    context = {
        'latitude': coords['lat'] if coords.get('lat') is not None else 'No definida',
        'longitude': coords['lng'] if coords.get('lng') is not None else 'No definida',
        'proveedores': proveedores,
        'categorias': categorias  # Añade las categorías al contexto para el filtro del formulario
    }

    return render(request, 'pages/categoria-tiendas.html', context)

def proveedor_tiendas(request, pk, proveedor):
    nom_proveedor = proveedor.replace('-', ' ')
    prov = get_object_or_404(Proveedor, id_proveedor=pk, proveedor=nom_proveedor)
    detalles_proveedor = DetalleProveedor.objects.filter(proveedor=prov)

    location_handler = LocationHandler(request)
    coords = location_handler.get_coordinates()  # Coordenadas de la sesión

    # Calcular la distancia para cada detalle de proveedor y agregarlo como un nuevo atributo
    for detalle in detalles_proveedor:
        if detalle.coordenada_x and detalle.coordenada_y:
            detalle.distancia = calcular_distancia(
                coords,
                {'lat': detalle.coordenada_x, 'lng': detalle.coordenada_y}
            )
        else:
            detalle.distancia = float('inf')  # Asignar infinito si no hay coordenadas disponibles

    # Ordenar los detalles de proveedor por distancia, del más cercano al más lejano
    detalles_proveedor = sorted(detalles_proveedor, key=lambda x: x.distancia)

    # Configurar paginación aquí
    paginator = Paginator(detalles_proveedor, 10)  # 10 detalles por página
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)

    context = {
        'latitude': coords['lat'] if coords.get('lat') is not None else 'No definida',
        'longitude': coords['lng'] if coords.get('lng') is not None else 'No definida',
        'prov': prov,
        'page_obj': page_obj,
    }

    return render(request, 'pages/proveedor-tiendas.html', context)

#########################################################################################################

def login_user(request):
    context={}
    if request.method == "POST":
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            messages.success(request, ("Sesion iniciada"))
            return redirect('index')
        else:
            messages.success(request, ("Error de autentificacion"))
            return redirect('login')
    else:
        return render(request, 'pages/signin.html', context )

def logout_user(request):
    logout(request)
    messages.success(request, ("Sesion Cerrada"))
    return redirect('index')

def about(request):
    context={}
    return render(request, 'pages/about.html', context )

#########################################################################################################

def pruebas(request):

    location_handler = LocationHandler(request)
    coords = location_handler.get_coordinates()  # Obtener las coordenadas de la sesión

    # Preparar el contexto con las coordenadas para pasarlo a la plantilla
    context = {
        'latitude': coords['lat'] if coords['lat'] is not None else 'No definida',
        'longitude': coords['lng'] if coords['lng'] is not None else 'No definida'
    }

    # Renderizar la plantilla HTML con las coordenadas disponibles
    return render(request, "pruebas.html", context)


def add_coords(request):
    lat = request.POST.get('latitude')
    lng = request.POST.get('longitude')
    print(f"{lat} y {lng}")
    if lat and lng:
        location_handler = LocationHandler(request)
        location_handler.set_coordinates(lat, lng)
        return JsonResponse({'status': 'success', 'message': 'Coordinates saved'})
    return JsonResponse({'status': 'error', 'message': 'Missing coordinates'})

    