# Create your models here.

from django.db import models
from django.utils import timezone

################################################### Profeco ###################################################

class Estado(models.Model):
    id_estado = models.IntegerField(primary_key=True)
    estado = models.CharField(max_length=255)

    def __str__(self):
        return self.estado

class CategoriaProveedor(models.Model):
    id_categoria_proveedor = models.IntegerField(primary_key=True)
    descripcion = models.CharField(max_length=255)

    def __str__(self):
        return self.descripcion

class Proveedor(models.Model):
    id_proveedor = models.IntegerField(primary_key=True)
    proveedor = models.CharField(max_length=255)
    categoria_proveedor = models.ForeignKey(CategoriaProveedor, on_delete=models.CASCADE)

    def __str__(self):
        return self.proveedor

class Municipio(models.Model):
    id_municipio = models.IntegerField(primary_key=True)
    municipio = models.CharField(max_length=255)
    estados = models.ForeignKey(Estado, on_delete=models.CASCADE)
    def __str__(self):
        return self.municipio

class DetalleProveedor(models.Model):
    id_detalleproveedor = models.IntegerField(primary_key=True)
    proveedor = models.ForeignKey(Proveedor, on_delete=models.CASCADE)
    nombre_del_proveedor = models.CharField(max_length=255, blank=True, null=True)
    direccion_del_proveedor = models.CharField(max_length=255, blank=True, null=True)
    coordenada_x = models.FloatField(blank=True, null=True)
    coordenada_y = models.FloatField(blank=True, null=True)
    municipio = models.ForeignKey(Municipio, on_delete=models.CASCADE)

    def __str__(self):
        return self.nombre_del_proveedor or ''

################################################### INEGI ################################################### 

class Especificacion(models.Model):
    id_especificacion = models.IntegerField(primary_key=True)
    especificacion = models.CharField(max_length=255)

    def __str__(self):
        return self.especificacion

class Generico(models.Model):
    id_generico = models.IntegerField(primary_key=True)
    nombre_generico = models.CharField(max_length=255)
    imagen = models.ImageField(upload_to='uploads/generico/', blank=True, null=True)

    def __str__(self):
        return self.nombre_generico

class Marca(models.Model):
    id_marca = models.IntegerField(primary_key=True)
    marca = models.CharField(max_length=255)

    def __str__(self):
        return self.marca

class GenericoMarcaEspecificacionRelacion(models.Model):
    id_generico = models.ForeignKey(Generico, on_delete=models.CASCADE)
    id_marca = models.ForeignKey(Marca, on_delete=models.CASCADE)
    id_especificacion = models.ForeignKey(Especificacion, on_delete=models.CASCADE)

    def __str__(self):
        return f"{self.id_generico} - {self.id_marca} - {self.id_especificacion}"

class Clase(models.Model):
    id_clase = models.IntegerField(primary_key=True)
    clase = models.CharField(max_length=255)

    def __str__(self):
        return self.clase

class ClaseGenericoRelacion(models.Model):
    id_clase = models.ForeignKey(Clase, on_delete=models.CASCADE)
    id_generico = models.ForeignKey(Generico, on_delete=models.CASCADE)  # Asumiendo que el modelo Generico ya está definido

    class Meta:
        unique_together = ('id_clase', 'id_generico')

    def __str__(self):
        return f"{self.id_clase.clase} - {self.id_generico.generico}"

class Ano(models.Model):
    ano = models.IntegerField(unique=True)

    def __str__(self):
        return str(self.ano)

class Mes(models.Model):
    mes = models.CharField(max_length=50, unique=True)

    def __str__(self):
        return self.mes

class Precio(models.Model):
    especificacion = models.ForeignKey(Especificacion, on_delete=models.CASCADE)
    ano = models.ForeignKey(Ano, on_delete=models.CASCADE)
    mes = models.ForeignKey(Mes, on_delete=models.CASCADE)
    precio = models.DecimalField(max_digits=10, decimal_places=2)  # Asumiendo que el precio es un valor decimal

    def __str__(self):
        return f"{self.especificacion} - {self.ano}/{self.mes}: {self.precio}"

class PrecioPromedio(models.Model):
    generico = models.ForeignKey(Generico, on_delete=models.CASCADE)
    marca = models.ForeignKey(Marca, on_delete=models.CASCADE)
    especificacion = models.ForeignKey(Especificacion, on_delete=models.CASCADE)
    ano = models.IntegerField()
    mes = models.IntegerField()
    precio_promedio = models.DecimalField(max_digits=10, decimal_places=2)

    def __str__(self):
        return f"{self.generico.nombre_generico} - {self.marca.marca} - {self.especificacion.especificacion} ({self.ano}-{self.mes}): {self.precio_promedio}"

################################################### ENCUESTA ###################################################

class Edad(models.Model):
    id_edad = models.IntegerField(primary_key=True)
    edad = models.IntegerField()

    def __str__(self):
        return str(self.edad)

class Entidad(models.Model):
    entidad = models.IntegerField(primary_key=True)
    descripcion_entidad = models.CharField(max_length=255)

    def __str__(self):
        return self.Descripcion_Entidad

class Sexo(models.Model):
    id_sexo = models.IntegerField(primary_key=True)
    descripcion = models.CharField(max_length=50)

    def __str__(self):
        return self.descripcion

class UsuarioIndice(models.Model):
    id_usuario = models.IntegerField(primary_key=True)
    folio_i = models.CharField(max_length=255)
    folio_int = models.CharField(max_length=255)

    def __str__(self):
        return f"{self.id_usuario} - {self.folio_i}"

class UsuarioDiasGenerico(models.Model):
    usuario = models.ForeignKey(UsuarioIndice, on_delete=models.CASCADE)
    generico = models.ForeignKey(Generico, on_delete=models.CASCADE)
    dias_consumidos = models.IntegerField() 

    def __str__(self):
        return f"{self.usuario} - {self.generico.id_generico} - {self.dias_consumidos}"

class RelacionCompletaUsuario(models.Model):
    usuario = models.ForeignKey(UsuarioIndice, on_delete=models.CASCADE)
    entidad = models.ForeignKey(Entidad, on_delete=models.CASCADE)
    sexo = models.ForeignKey(Sexo, on_delete=models.CASCADE)
    edad = models.ForeignKey(Edad, on_delete=models.CASCADE)

    def __str__(self):
        return f"{self.usuario} - {self.entidad} - {self.sexo} - {self.edad}"


################################################### PostA-gregados ###################################################

class CategoriaProveedorGenerico(models.Model):
    categoria_proveedor = models.ForeignKey(CategoriaProveedor, on_delete=models.CASCADE)
    id_generico = models.ForeignKey(Generico, on_delete=models.CASCADE)

    def __str__(self):
        return f"{self.categoria_proveedor.descripcion} - {self.generico.nombre_generico}"

class Contacto(models.Model):
    nombre = models.CharField(max_length=100)
    apellido = models.CharField(max_length=100)
    titulo = models.CharField(max_length=200, blank=True)
    email = models.EmailField()
    comentario = models.TextField()

    def __str__(self):
        return f"{self.nombre} {self.apellido} - {self.email}"

class Review(models.Model):
    producto_especifico = models.ForeignKey(Especificacion, on_delete=models.CASCADE, related_name='reviews')
    titulo = models.CharField(max_length=255)
    comentario = models.TextField()
    calificacion = models.IntegerField(choices=[(i, f'{i} estrellas') for i in range(1, 6)])
    fecha_creacion = models.DateTimeField(default=timezone.now)
    session_key = models.CharField(max_length=40)

    def __str__(self):
        return f'{self.titulo} - {self.producto.nombre} - {self.calificacion}/5 estrellas'