from django.contrib import admin
from .models import Estado, CategoriaProveedor, Proveedor, Municipio, DetalleProveedor, Especificacion, Generico, Marca, GenericoMarcaEspecificacionRelacion, Clase, ClaseGenericoRelacion

# Register your models here.

from django.contrib import admin
from .models import Estado, CategoriaProveedor, Proveedor, Municipio, DetalleProveedor, Especificacion, Generico, Marca, GenericoMarcaEspecificacionRelacion, Clase, ClaseGenericoRelacion

@admin.register(Estado)
class EstadoAdmin(admin.ModelAdmin):
    list_display = ['id_estado', 'estado']

@admin.register(CategoriaProveedor)
class CategoriaProveedorAdmin(admin.ModelAdmin):
    list_display = ['id_categoria_proveedor', 'descripcion']

@admin.register(Proveedor)
class ProveedorAdmin(admin.ModelAdmin):
    list_display = ['id_proveedor', 'proveedor', 'categoria_proveedor']

@admin.register(Municipio)
class MunicipioAdmin(admin.ModelAdmin):
    list_display = ['id_municipio', 'municipio', 'estados']

@admin.register(DetalleProveedor)
class DetalleProveedorAdmin(admin.ModelAdmin):
    list_display = ['id_detalleproveedor', 'proveedor', 'nombre_del_proveedor', 'direccion_del_proveedor', 'coordenada_x', 'coordenada_y', 'municipio']

@admin.register(Especificacion)
class EspecificacionAdmin(admin.ModelAdmin):
    list_display = ['id_especificacion', 'especificacion']

@admin.register(Generico)
class GenericoAdmin(admin.ModelAdmin):
    list_display = ['id_generico', 'nombre_generico', 'imagen']

@admin.register(Marca)
class MarcaAdmin(admin.ModelAdmin):
    list_display = ['id_marca', 'marca']

@admin.register(GenericoMarcaEspecificacionRelacion)
class GenericoMarcaEspecificacionRelacionAdmin(admin.ModelAdmin):
    list_display = ['id_generico', 'id_marca', 'id_especificacion']

@admin.register(Clase)
class ClaseAdmin(admin.ModelAdmin):
    list_display = ['id_clase', 'clase']

@admin.register(ClaseGenericoRelacion)
class ClaseGenericoRelacionAdmin(admin.ModelAdmin):
    list_display = ['id_clase', 'id_generico']
